"""
DynamoDB Helper class
Author: Komuraiah Theerthala
"""

import boto3
import logging
from boto3.dynamodb.conditions import Key
from aws_xray_sdk.core import xray_recorder

class DynamoDBHelper:
    """
    A helper class for interacting with DynamoDB.
    """

    def __init__(self, table_name):
        """
        Initialize the DynamoDBHelper.

        Args:
            table_name (str): The name of the DynamoDB table.
        """
        self.table_name = table_name
        self.dynamodb = boto3.resource('dynamodb')
        self.table = self.dynamodb.Table(self.table_name)
        self.logger = logging.getLogger(__name__)
        self.logger.setLevel(logging.INFO)  # Set your desired logging level here

    @xray_recorder.capture('dynamodb_query')
    def get_item(self, key, key_value):
        """
        Perform a query on the DynamoDB table.

        Args:
            key (str): The key attribute to query on.
            key_value: The value to match for the query.

        Returns:
            list: A list of items matching the query.
        """
        try:
            response = self.table.query(
                KeyConditionExpression=Key(key).eq(str(key_value))
            )
            return response['Items']
        except Exception as e:
            self.logger.error("Error querying DynamoDB: %s", e)
            raise

    @xray_recorder.capture('dynamodb_query')
    def dynamodb_get_item(self, key, key_value,attribute):
        """
        Perform a query on the DynamoDB table.

        Args:
            key (str): The key attribute to query on.
            key_value: The value to match for the query.

        Returns:
            list: A list of items matching the query.
        """
        try:
            if attribute != None:
                response = self.table.query(
                    KeyConditionExpression=Key(key).eq(key_value),
                    ProjectionExpression=attribute
                )
                return response
            else:
                response = self.table.query(
                    KeyConditionExpression=Key(key).eq(key_value)
                )
                return response
        except Exception as e:
            self.logger.error("Error querying DynamoDB: %s", e)
            raise

    @xray_recorder.capture('dynamodb_query')
    def query(self, key, key_value, exclusive_start_key, attribute):
        """
        Perform a query on the DynamoDB table.

        Args:
            key (str): The key attribute to query on.
            key_value: The value to match for the query.
            options: The key value pair of an extra parameter 

        Returns:
            list: A list of items matching the query.
        """
        try:
            response = self.table.query(
                KeyConditionExpression=Key(key).eq(str(key_value)), 
                ProjectionExpression=attribute,
                ExclusiveStartKey=exclusive_start_key
            )
            return response['Items']
        except Exception as e:
            self.logger.error("Error querying DynamoDB: %s", e)
            raise

    @xray_recorder.capture('dynamodb_put_item')
    def put_item(self, item):
        """
        Put an item into the DynamoDB table.

        Args:
            item (dict): The item to put into the table.
        """
        try:
            self.table.put_item(Item=item)
        except Exception as e:
            self.logger.error("Error putting item into DynamoDB: %s", e)
            raise
