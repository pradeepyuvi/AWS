# Ingestion Lambda

This Lambda Function will be triggered once the boundary system hit the API Gateway URL. The lambda will receive the payload from boundary system in the event and it will convert in to Json file. The file will be storing in to the S3 Bucket.

