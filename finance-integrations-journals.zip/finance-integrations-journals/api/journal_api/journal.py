import json
import uuid
import os
import datetime
import logging
import boto3



logger = logging.getLogger()
logger.setLevel(logging.INFO)

s3 = boto3.client('s3')
def load(event, context):
    try:
        bucket = os.environ.get('bucket_name')
        if bucket is None:
            return {
                "statusCode": 500,
                "body": json.dumps({
                    "error": "System is not responding. Please contact System Adminstrator."
                })
            }

        data = event.get('body', '')
        payload = json.loads(data)

        # GroupID as integer timestamp in milliseconds. Some updates to trigger CI
        group_id = generate_group_id()
        tracking_id = generate_tracking_id()
        journal_source_name = payload['journalBatch']['journalSourceName']
        json_file_name = journal_source_name + "_GL110_JournalImport_" + group_id
        je_lines = len(payload['journalBatch']['journalLines'])
        payload['consumer']['ipaddress'] = '192.168.0.1'
        payload['consumer']['type'] = 'api'
        payload['consumer']['account'] = 'apigeeappname'
        reference_id = None
        if 'consumerReferenceId' in payload['consumer']:
            reference_id = payload['consumer']['consumerReferenceId']
            del payload['consumer']['consumerReferenceId']
        
        s3.put_object(Bucket=bucket, Key='inbox/'+json_file_name+".json", Body=data)
        update_dynamodb(group_id, payload, tracking_id, bucket,
                        json_file_name, je_lines, reference_id)

        if je_lines == 0:
            return {
                "statusCode": 400,
                "body": json.dumps({
                    "error": "journal lines data is not found."
                })
            }

        body = prepare_response_body(
            tracking_id, group_id, json_file_name, je_lines)
        return {"statusCode": 200, "body": json.dumps(body)}
    except Exception as error:
        error_msg = "failed due to an error: " + str(error)
        logger.error(error_msg)
        update_error_dynamodb(group_id, reference_id, json_file_name, error_msg)
        return {
            "statusCode": 500,
            "body": json.dumps({
                "error": "System is not responding. Please contact System Adminstrator."
            })
        }


def generate_group_id():
    current_time = datetime.datetime.now()
    group_id = current_time.strftime("%Y%m%d%H%M%S%f")[:-3]
    return group_id


def generate_tracking_id():
    randomuuid = uuid.uuid4()
    tracking_id = str(randomuuid)
    return tracking_id


def prepare_response_body(tracking_id, group_id, json_file_name, je_lines):
    body = {
        "message": "Journal Import payload received successfully!",
        "trackingId": tracking_id,
        "groupId": group_id,
        "fileName": json_file_name,
        "totalLines": je_lines
    }
    return body


def update_dynamodb(group_id, payload, tracking_id, bucket, file_name, je_lines, reference_id):

    item = {
        'groupId': group_id,
        'uuid': tracking_id,
        'referenceId': reference_id,
        'consumer': payload['consumer'],
        'fileName': file_name,
        'request': {
            'date': str(datetime.datetime.now()),
            'bucket': bucket,
            'key': 'inbox/'+file_name,
            'source': payload['journalBatch']['journalSourceName'],
            'totalLines': je_lines
        },
        'status': {
            'key': 'In-progress',
            'message': 'Received payload'

        }
    }
    create_dynamodb(item)

def create_dynamodb(body):
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table(os.environ.get(
            'journal_table'))
    table.put_item(Item=body)


def update_error_dynamodb(group_id,reference_id,file_name, msg,):
    item = {
        'groupId': str(group_id) if group_id else '',
        'fileName': str(file_name),
        'referenceId': str(reference_id),
        'request': {
            'date': str(datetime.datetime.now())
        },
        'status': {
            'key': 'failed',
            'message': msg

        }
    }
    create_dynamodb(item)