import toml
import sys

def main():
    data = toml.load("samconfig.toml")
    stage = str(sys.argv[1])
    print(data[stage]["deploy"]["parameters"]["parameter_overrides"])
    return data[stage]["deploy"]["parameters"]["parameter_overrides"]

if __name__ == '__main__':
    main()