# gl_download Lambda

This Lambda function processes files in S3 and transforms them into JSON objects with the specified JSON schema. 
The input files can either be in CSV or JSON format. If the input file is a CSV, the function parses the file and constructs a JSON object. If the input file is a JSON, it extracts the relevant fields and constructs a JSON object.
The constructed JSON object is then validated with the JSON schema. If the validation succeeds, the JSON object is uploaded to S3 as a new file.

