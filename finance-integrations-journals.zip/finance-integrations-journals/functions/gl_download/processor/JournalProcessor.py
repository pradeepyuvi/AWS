import json
import csv
import os
import datetime
# import uuid
from jsonschema import ValidationError
import logging
import boto3
from jsonschema import ValidationError, validate
try:
    from common.helper.DynamoDBHelper import DynamoDBHelper
except ImportError:
    from layers.python.common.helper.DynamoDBHelper import DynamoDBHelper

class JournalProcessor:
    def __init__(self, event):
        self.event = event
        self.bucket = event['bucket']
        self.key = event['key']
        self.group_id = event['groupId']
        self.file_name = event['fileName']
        self.s3_folder_path = 'process/'
        self.consumer = event.get('consumer', None)
        self.JOURNAL_TABLE_NAME = 'journal_table'
        self.logger = logging.getLogger(__name__)
        self.logger.setLevel(logging.INFO)  # Set your desired logging level here

    def process(self):
        if self.key.endswith('.json'):
            [journal_lines, total_debit_amount, total_credit_amount, journal_source_name] = self.process_json_file()
        elif self.key.endswith('.csv'):
            [journal_lines, total_debit_amount, total_credit_amount, journal_source_name] = self.process_csv_file()

        self.event['totalDebitAmount'] = round(total_debit_amount,2)
        self.event['totalCreditAmount'] = round(total_credit_amount,2)
        self.event['totalLines'] = len(journal_lines)
        self.event['source'] = journal_source_name
        self.event['key'] = self.s3_folder_path + self.file_name
        transactions = json.dumps(journal_lines, indent=2, default=str)
        schema_file = open('journal.json')
        json_schema = json.load(schema_file)

        validate_error = self.validate_json_schema(journal_lines, json_schema)
        if not validate_error:
            self.upload_to_s3(transactions)
            self.update_dynamodb()
        return self.event

    def process_json_file(self):
        journal_lines = []
        total_debit_amount = 0.00
        total_credit_amount = 0.00
        json_file = self.get_data_from_s3(self.bucket, self.key)
        body = json.loads(json_file['Body'].read().decode('utf-8'))
        journal_lines = body['journalBatch']['journalLines']
        journal_source_name = body['journalBatch']['journalSourceName']
        journal_category_name = body['journalBatch']['journalCategoryName']
        #Check Journal Source and Category
        self.check_source_and_category(journal_source_name, journal_category_name)
        accounting_date = body['journalBatch']['accountingDate']

        count = 1
        for transaction in journal_lines:
            self.logger.info(transaction)
            transaction['journalSourceName'] = journal_source_name
            transaction['journalCategoryName'] = journal_category_name
            transaction['accountingDate'] = accounting_date
            transaction['groupId'] = self.group_id
            transaction['count'] = count
            if ('debitAmount' in transaction):
                total_debit_amount += transaction['debitAmount']
            elif ('creditAmount' in transaction):
                total_credit_amount += transaction['creditAmount']
            count += 1
        if total_credit_amount != total_debit_amount:
            raise ValueError(f"Debit amount ({total_debit_amount}) doesn't match Credit amount ({total_credit_amount})")
        return [journal_lines, total_debit_amount, total_credit_amount, journal_source_name]

    def process_csv_file(self):
        journal_lines = []
        total_debit_amount = 0.00
        total_credit_amount = 0.00
        self.logger.info('Detected CSV file' + self.key)
        csv_file = self.get_data_from_s3(self.bucket, self.key)
        record_list = csv_file['Body'].read().decode('utf-8').split("\n")
        csv_reader = csv.reader(record_list, delimiter=',', quotechar='"')

        index = 0
        for row_data in csv_reader:
            self.validate_length_csv(index, row_data)
            if index == 0:
                journal_source_name = row_data[0].strip()
                journal_category_name = row_data[1].strip()
                #Check Journal Source and Category
                self.check_source_and_category(journal_source_name, journal_category_name)
                accounting_date = row_data[3].strip()
                index += 1
            else:
                if (len(row_data)) == 0:
                    break
                debit_amount = 0.00
                credit_amount = 0.00
                if (row_data[14]):
                    debit_amount = float(row_data[14])
                    total_debit_amount += debit_amount
                if (row_data[15]):
                    credit_amount = float(row_data[15])
                    total_credit_amount += credit_amount

                journal_line = {
                    "count": index,
                    "journalSourceName": journal_source_name,
                    "journalCategoryName": journal_category_name,
                    "accountingDate": accounting_date,
                    "groupId": self.group_id,
                    "journalName": row_data[0].strip(),
                    "journalDescription": row_data[1].strip(),
                    "balanceType": row_data[2].strip(),
                    "coaSegments": {
                        "entity": row_data[3].strip(),
                        "financialUnit": row_data[4].strip(),
                        "fund": row_data[5].strip(),
                        "account": row_data[6].strip(),
                        "transactionClass": row_data[7].strip(),
                        "program": row_data[8].strip(),
                        "portfolio": row_data[9],
                        "flex": row_data[10],
                        "activity": row_data[11],
                        "intercompany": row_data[12],
                        "future": row_data[13]
                    },
                    "debitAmount": round(debit_amount, 2),
                    "creditAmount": round(credit_amount, 2),
                    "JournalLineDescription": row_data[16],
                    "reconciliationReference": row_data[17],
                    "journalLineReference2": row_data[18],
                    "journalLineReference3": row_data[19]
                }
                index += 1
                journal_lines.append(journal_line)
        if total_credit_amount != total_debit_amount:
            raise ValueError(f"Debit amount ({total_debit_amount}) doesn't match Credit amount ({total_credit_amount})")
        return [journal_lines, total_debit_amount, total_credit_amount, journal_source_name]

    def validate_json_schema(self, json_data, json_schema):
        try:
            validate_error = validate(instance=json_data, schema=json_schema)
            return validate_error
        except ValidationError as e:
            if (e.validator == 'pattern'):
                msg = e.relative_path.pop() + " cannot be empty"
            else:
                msg = e.message
            raise ValidationError('failed due to validation error: ' + msg)

    def upload_to_s3(self, body):
        s3 = boto3.client('s3')
        s3.put_object(Bucket=self.bucket, Key=self.s3_folder_path + self.file_name, Body=body)

    def update_dynamodb(self):
        dynamodb_helper = DynamoDBHelper(os.environ.get(self.JOURNAL_TABLE_NAME))
        response = dynamodb_helper.get_item('groupId', self.group_id)

        if not response:
            item = self.create_dynamodb_item()
        else:
            item = response[0]
            item['request']['totalDebitAmount'] = str(self.event['totalDebitAmount'])
            item['request']['totalCreditAmount'] = str(self.event['totalCreditAmount'])

        dynamodb_helper.put_item(item)

    def create_dynamodb_item(self):
        item = {
            'groupId': str(self.group_id),
            'consumer': self.consumer,
            'referenceId': None,
            'fileName': str(self.file_name),
            'request': {
                'date': str(datetime.datetime.now()),
                'bucket': self.bucket,
                'key': self.key,
                'source': self.event['source'],
                'totalLines': self.event['totalLines'],
                'totalCreditAmount': str(self.event['totalCreditAmount']),
                'totalDebitAmount': str(self.event['totalDebitAmount'])
            },
            'status': {
                'key': 'In-progress',
                'message': 'Received payload'
            }
        }
        return item

    def get_data_from_s3(self, bucket, key):
        s3 = boto3.client('s3')
        content = s3.get_object(Bucket=bucket, Key=key)
        return content

    def validate_length_csv(self, index, row_data):
        if index == 0 and len(row_data) != 4:
            raise ValidationError('CSV file is incorrect, All the required fields in journalBatch are not provided')
        elif len(row_data) != 20 and index != 0:
            raise ValidationError('CSV file is incorrect, All the required fields in journalLines are not provided')
        
    def check_source_and_category(self, journal_source_name, journal_category_name):
        journal_source_name = journal_source_name.lower()
        journal_category_name = journal_category_name.lower()
        with open('processor/source_category.json', 'r') as file:
            json_data = json.load(file)
        
        if not (journal_source_name in json_data and (journal_category_name in json_data[journal_source_name] if isinstance(json_data[journal_source_name], list) else journal_category_name == json_data[journal_source_name])):
            raise ValueError(f"Source Name: {journal_source_name} and Category Name: {journal_category_name} is invalid.")
