

import os
import datetime
import logging
from processor.JournalProcessor import JournalProcessor

try:
    from common.helper.DynamoDBHelper import DynamoDBHelper
except ImportError:
    from layers.python.common.helper.DynamoDBHelper import DynamoDBHelper


logger = logging.getLogger()
logger.setLevel(logging.INFO)

JOURNAL_TABLE_NAME = 'journal_table'


def handler(event, context):
    try:
        logger.info(event)
        group_id = event['groupId']
        if event['key'].endswith('.csv') or event['key'].endswith('.json'):
            processor = JournalProcessor(event)
            return processor.process()
        else:
            raise ValueError("Unsupported file type. Only CSV and JSON files are allowed.")
    except Exception as error:
        logger.info("inside exception")
        error_msg = "failed due to an error: " + str(error)
        logger.error(error)
        update_error_dynamodb(group_id, event['fileName'], error_msg)
        raise error

def update_error_dynamodb(group_id, file_name, msg):
    dynamodb_helper = DynamoDBHelper(os.environ.get(JOURNAL_TABLE_NAME))
    response = dynamodb_helper.get_item('groupId', group_id)

    if not response:
        item = {
            'groupId': str(group_id) if group_id else '',
            'fileName': str(file_name),
            'request': {
                'date': str(datetime.datetime.now()),
            },
            'status': {
                'key': 'failed',
                'message': msg
            }
        }
    else:
        item = response[0]
        item['status'] = {
            'key': 'failed',
            'message': msg
        }

    dynamodb_helper.put_item(item)
