import json
import boto3
import os
import csv
import zipfile
import logging
import boto3
import datetime
from jsonschema import ValidationError
try:
    # This import will work in the Lambda environment
    from common.helper.DynamoDBHelper import DynamoDBHelper
except ImportError:
    # This import will work during local testing
    from layers.python.common.helper.DynamoDBHelper import DynamoDBHelper


# stepfunctions = boto3.client('stepfunctions')
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Declare the DynamoDB table names
FBDI_TABLE_NAME = 'fbdi_table'
GL_INTERFACE_TABLE_NAME = 'gl_interface_table'
JOURNAL_TABLE_NAME = 'journal_table'

def handler(event, context):
    try:
        fbdi_bucket = os.environ.get('bucket_name')
        group_id = event['groupId']
        initiate_dynamodb_query(group_id)
        
        data_access_id = os.environ['data_access_id']

        # name of the CSV file to be added to the ZIP file
        csv_filename = '/tmp/GLInterface.csv'

        # name of the ZIP file to be created
        fbdi_file = source + "_GL110_JournalImport_" + str(group_id)
        fbdi_file_with_extension = fbdi_file + ".zip"

        zip_filename = "/tmp/" + fbdi_file_with_extension

        # create a new ZIP file and add the CSV file to it
        with zipfile.ZipFile(zip_filename, "w") as zip_file:
            zip_file.write(csv_filename, arcname='GLInterface.csv')
        
        s3 = boto3.client('s3')
        s3.upload_file(zip_filename, fbdi_bucket, 'process/' + fbdi_file_with_extension)
        # delete files created
        if os.path.exists(csv_filename):
            os.remove(csv_filename)
        else:
            logger.info("The file does not exist")

        if os.path.exists(zip_filename):
            os.remove(zip_filename)
        else:
            logger.info("The file does not exist")
        db_helper = DynamoDBHelper(os.environ.get(JOURNAL_TABLE_NAME))
        response_obj = db_helper.get_item('groupId', group_id)
        item={}
        if response_obj:
            item=response_obj[0]
        
        total_debit_amount = ''
        total_credit_amount = ''
        if (item):
            total_debit_amount = item['request']['totalDebitAmount']
            total_credit_amount = item['request']['totalCreditAmount']
        payload = {
            'Payload': {
                'request': {
                    'data': {
                        'bucket': fbdi_bucket,
                        'fileName': 'process/' + fbdi_file_with_extension,
                        'source': source,
                        'totalLines': total_lines,
                        'totalDebitAmount': total_debit_amount,
                        'totalCreditAmount': total_credit_amount
                    },
                    'essJobParameters': {
                        'groupId': group_id,
                        'parameterList': str(data_access_id) + ',' + str(source) + ',' + str(ledger_id) + ',' + str(group_id) + ',N,N,N'
                    }
                },
                'process': 'journal'
            }
        }
        # journal_status_workflow = os.environ.get(
        #     'journal_status_workflow_state_machine')

        # response = stepfunctions.start_execution(
        #     stateMachineArn=journal_status_workflow, input=json.dumps(payload))
        # logger.info(response)

        return payload
    except Exception as error:
        error_msg= "Failed due to an error: " + str(error)
        logger.error(error)
        update_error_dynamodb(group_id,None,error_msg)
        raise error
        

def write2csv(writer, items):
    for item in items:
        line = json.loads(item['csv_records'])
        for j in line:
            writer.writerow(j)


def update_error_dynamodb(group_id,file_name, msg):
    dynamodb_helper = DynamoDBHelper(os.environ.get(JOURNAL_TABLE_NAME))
    response = dynamodb_helper.get_item('groupId', group_id)
    if not response:
        item = {
            'groupId': str(group_id) if group_id else '',
            'fileName': str(file_name),
            'request': {
                'date': str(datetime.datetime.now()),
            },
            'status': {
                'key': 'failed',
                'message': msg

            }
        }
    else:
        item = response[0]
        item['status'] = {
            'key': 'failed',
            'message': msg

        }
    dynamodb_helper.put_item(item)

# To initiate the dynamodb query and start the creation of csv
def initiate_dynamodb_query(group_id):
    try:
        dynamodb_utility = DynamoDBHelper(table_name=os.environ.get(GL_INTERFACE_TABLE_NAME))
        primary_response = dynamodb_utility.dynamodb_get_item("groupId", str(group_id), 'csv_records')
        create_csv_file(primary_response, group_id)
    except Exception as error:
        logger.error(error)
        raise


# To create the CSV file
def create_csv_file(records_response, group_id):
    try:
        dynamodb_utility = DynamoDBHelper(table_name=os.environ.get(GL_INTERFACE_TABLE_NAME))
        global writer
        csv_filename = '/tmp/GLInterface.csv'
        with open(csv_filename, 'w', newline='') as file:
            writer = csv.writer(file)
            if len(records_response['Items']) > 0:
                update_csv_file(records_response['Items'])

            while 'LastEvaluatedKey' in records_response:
                key = records_response['LastEvaluatedKey']
                records_response = dynamodb_utility.query("groupId", group_id, key, 'csv_records')
                if len(records_response) > 0:
                    update_csv_file(records_response)
    except Exception as error:
        logger.error(error)
        raise


# To update the csv file
def update_csv_file(records_list):
    non_empty_lines = 0
    global ledger_id, source
    splitted_csv_records = records_list[0]['csv_records'].split(',')
    ledger_id = splitted_csv_records[1][2:-1]
    source = splitted_csv_records[3][2:-1]
    for record in records_list:
        if len(json.loads(record['csv_records'])) > 0:
            non_empty_lines += 1
            line = json.loads(record['csv_records'])
            global total_lines
            total_lines = 0
            for record_line in line:
                total_lines+=1
                writer.writerow(record_line)
    if non_empty_lines == 0:
        raise ValidationError("csv records is empty")