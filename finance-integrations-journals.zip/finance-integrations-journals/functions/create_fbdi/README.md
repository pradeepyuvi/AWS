# create_fbdi Lambda

This lambda function takes an input event containing a 'groupId' and queries a DynamoDB table for records matching that groupId. The records contain CSV data that is concatenated into a single CSV file, which is then zipped and uploaded to an S3 bucket. The function also creates a payload containing information about the uploaded file and returns.

