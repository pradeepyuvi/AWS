# gl_interface Lambda

This Lambda function reads events data and creates a set of CSV records to be written to a DynamoDB table. It extracts relevant data from the event, constructs a body with this data and adds to the CSV record list. Finally, it writes the CSV record list to the DynamoDB table along with some data such as the group id and a unique id and store it in DynamoDB.

