import json
import logging
import os
import datetime
import shortuuid

try:
    from common.helper.DynamoDBHelper import DynamoDBHelper
except ImportError:
    from layers.python.common.helper.DynamoDBHelper import DynamoDBHelper

logger = logging.getLogger()
logger.setLevel(logging.INFO)

JOURNAL_TABLE_NAME = 'journal_table'
GL_INTERFACE_TABLE_NAME = 'gl_interface_table'

def handler(events, context):
    try:
        global uuid_str
        uuid_str = str(shortuuid.uuid())
        csv_records = []
        for event in events['Items']:
            logger.info(f"event: {event}")
            coa_segments = event['coaSegments']
            journal_line = event
            debit_amount = 0.00
            credit_amount = 0.00
            if ('debitAmount' in journal_line):
                debit_amount = journal_line['debitAmount']
            if ('creditAmount' in journal_line):
                credit_amount = journal_line['creditAmount']
            journal_source_name = event['journalSourceName']
            journal_category_name = event['journalCategoryName']
            accounting_date = event['accountingDate']
            group_id = event['groupId']
            ledger_id = os.environ['ledger_id']
            body = ['NEW',
                    ledger_id,
                    accounting_date,
                    journal_source_name,
                    journal_category_name,
                    'USD',
                    accounting_date,
                    journal_line['balanceType'],
                    coa_segments['entity'],
                    coa_segments['financialUnit'],
                    coa_segments['fund'],
                    coa_segments['account'],
                    coa_segments['transactionClass'],
                    coa_segments['program'],
                    coa_segments['portfolio'] if 'portfolio' in coa_segments else '',
                    coa_segments['flex'] if 'flex' in coa_segments else '',
                    coa_segments['activity'] if 'activity' in coa_segments else '',
                    coa_segments['intercompany'],
		            coa_segments['future'],
                    '0', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
                    debit_amount,
                    credit_amount,
                    '',
                    '',
                    '',
                    '',
                    '',
                    journal_line['journalName'],
                    journal_line['journalDescription'],
                    journal_line['reconciliationReference'] if 'reconciliationReference' in journal_line else '',
                    '',
                    '',
                    '',
                    journal_line['JournalLineDescription'] if 'JournalLineDescription' in journal_line else '',
                    '', '', '', '', '', '',
                    journal_line['journalLineReference2'] if 'journalLineReference2' in journal_line else '',
                    journal_line['journalLineReference3'] if 'journalLineReference3' in journal_line else '',
                    '', '', '', '', '', '',
                    group_id, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'END', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'END']

            csv_records.append(body)

        write2dydb(group_id, csv_records)
        return group_id
    except Exception as error:
        error_msg= "failed due to an error: " + str(error)
        logger.error(error)
        update_error_dynamodb(group_id,None,error_msg)
        raise error


def write2dydb(group_id, body):
    try:
        time = datetime.datetime.now()

        item = {
            'groupId': str(group_id),
            'uuid': uuid_str,
            'csv_records': json.dumps(body),
            'count': len(body),
            'date_created': str(time)
        }
        logger.info("Write to Dynamo DB:" + json.dumps(item))
        create_dynamodb(os.environ.get(GL_INTERFACE_TABLE_NAME),item)
    except Exception as e:
        logger.info("Error " + str(e))




def create_dynamodb(table_name, body):
    dynamodb_helper = DynamoDBHelper(table_name)
    dynamodb_helper.put_item(body)


def update_error_dynamodb(group_id,file_name, msg):
    dynamodb_helper = DynamoDBHelper(os.environ.get(JOURNAL_TABLE_NAME))
    response = dynamodb_helper.get_item('groupId', group_id)
    if not response:
        item = {
            'groupId': str(group_id) if group_id else '',
            'fileName': str(file_name),
            'request': {
                'date': str(datetime.datetime.now()),
            },
            'status': {
                'key': 'failed',
                'message': msg

            }
        }
    else:
        item = response['Items'][0]
        item['status'] = {
            'key': 'failed',
            'message': msg

        }
    create_dynamodb(os.environ.get(JOURNAL_TABLE_NAME),item)