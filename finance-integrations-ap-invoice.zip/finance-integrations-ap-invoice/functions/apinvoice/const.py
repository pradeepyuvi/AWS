ORACLE_REQUEST_PATH = '/xmlpserver/services/ExternalReportWSSService'
XML_FILE_NAME = "source_request.xml"