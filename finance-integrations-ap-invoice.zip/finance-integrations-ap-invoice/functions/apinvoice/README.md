# APINVOICE_FBDI LAMBDA

This Lambda function will retrieve the input file from the source boundary system (S3 bucket), invoke the common workflow with the payload, handle errors, and update the data in DynamoDB.