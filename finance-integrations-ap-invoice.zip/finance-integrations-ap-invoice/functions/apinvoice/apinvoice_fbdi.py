import boto3
import os
import datetime
import logging
import json
import sys
from os import environ
import zipfile
import io
import csv
import requests
import xmltodict
from base64 import b64decode


try:
    import const
except ImportError:
    from . import const


try:
    # This import will work in the Lambda environment
    from apinvoice.utility.Boto3Utility import Boto3Utility
except ImportError:
    # This import will work during local testing
    sys.path.append('../../')
    from layers.python.apinvoice.utility.Boto3Utility import Boto3Utility
    
s3 = boto3.client('s3')
logger_level = os.environ.get('logger_level', 'INFO')
logger = logging.getLogger()
logger.setLevel(logger_level)
FBDI_TABLE_NAME = 'fbdi_table'
records_db_utility = Boto3Utility(table_name=os.environ.get("InvalidRecordsTable"))


# A lambda handler function
def handler(event, context):
  global group_id
  try:
    global s3_utility
    group_id = generate_group_id()
    get_secret(environ['secret_name'],environ['region_name'])
    bucket = os.environ.get('bucket_name')
    s3_utility = Boto3Utility(bucket_name=bucket)
    # records_db_utility = Boto3Utility(RECORDS_TABLE=os.environ.get("InvalidRecordsTable"))
    key = event['key']
    file_name = key.split('/')[-1].split('.')[0] + '.zip'
    source = key.split('/')[2].split('_')[0].upper()
    parameters_data = os.environ.get('parameter_list')
    parameter_list = get_parameter(parameters_data)
    parameters_values = ','.join(parameter_list)
    
    parameters_values = parameters_values.replace('apinvoice_organization_id', organization_id)
    parameters_values = parameters_values.replace('apinvoice_ledger_id', ledger_id)
    parameters_values = parameters_values.replace('Boundary_source', source)
    extract_file(bucket, key)

    payload = {
       'Payload': {
          'request': {
              'data': {
                  'bucket': bucket,
                  'fileName': key,
                  'Boundary_source': source,
                  'operation': 'ApInvoice'
              },
              'essJobParameters': {
                  'groupId': group_id,
                  "parameterList": parameters_values
              }
          },
          'process': 'ApInvoice'
       }
    }

    
    update_dynamodb(group_id, file_name)
    return payload
   
  except Exception as error:
    error_msg = "failed due to an error: " + str(error)
    logger.error('error: ' + str(error))
    if group_id is not None:
            update_error_dynamodb(group_id, file_name, error_msg)
    else:
        raise error
        

def insert_invalid_records_into_dynamodb(invalid_records):
    for group_id, records in invalid_records.items():
        item = {'groupId': group_id, 'invalidRecords': records}
        records_db_utility.put_item(item=item)


def extract_file(bucket, key):
    ApInvoiceLinesInterface = []
    ApInvoicesInterface = []
    
    obj = s3.get_object(Bucket=bucket, Key=key)
    zip_data = io.BytesIO(obj['Body'].read())

    with zipfile.ZipFile(zip_data, 'r') as zip_ref:
        file_list = zip_ref.namelist()
        for file in file_list:
            if file.endswith('.csv'):
                with zip_ref.open(file) as csv_file:
                    csv_data = csv_file.read().decode('utf-8')
                    if file == 'ApInvoiceLinesInterface.csv':
                        ApInvoiceLinesInterface = csv_data
                    elif file == 'ApInvoicesInterface.csv':
                        ApInvoicesInterface = csv_data
    
    input_data = {
        "ApInvoiceLinesInterface": ApInvoiceLinesInterface.split('\n'),
        "ApInvoicesInterface": ApInvoicesInterface.split('\n')
    }
    
    business_units, sources = boundary_inputs()
    valid_lines_interface, valid_invoices_interface, ApInvoiceLinesInterface, ApInvoicesInterface = validate_data(input_data, business_units, sources)
    
    return valid_lines_interface, valid_invoices_interface, ApInvoiceLinesInterface, ApInvoicesInterface

def validate_data(input_data, business_units, sources):
    valid_lines_interface = []
    valid_invoices_interface = []
    invalid_lines_interface = []
    invalid_invoices_interface = []

    for line_interface, invoice_interface in zip(input_data["ApInvoiceLinesInterface"], input_data["ApInvoicesInterface"]):
        line_data = line_interface.split(',')
        invoice_data = invoice_interface.split(',')

        invalid_line = any(not data for data in [line_data[i] for i in [0, 1, 2, 3, 4, 5, 8, 13, 19]])
        invalid_invoice = any(not data for data in [invoice_data[i] for i in [1, 2, 3]])

        if invalid_line:
            invalid_lines_interface.append(line_interface)
            invalid_invoices_interface.append(invoice_interface)
        elif invalid_invoice:
            invalid_lines_interface.append(line_interface)
            invalid_invoices_interface.append(invoice_interface)
        else:
            bu_match = invoice_data[1] in business_units
            source_match = invoice_data[2] in sources
            
            if not bu_match or not source_match:
                invalid_lines_interface.append(line_interface)
                invalid_invoices_interface.append(invoice_interface)
            else:
                valid_lines_interface.append(line_interface)
                valid_invoices_interface.append(invoice_interface)

    invalid_records = []
    for invoice in invalid_invoices_interface:
        invoice_data = invoice.split(',')
        record = {
            "VENDOR_NAME": "",
            "INVOICE_DATE": invoice_data[5],
            "INVOICE_NUM": invoice_data[3],
            "INVOICE_ID": invoice_data[0],
            "STATUS": "not processed",
            "ERROR_MESSAGE": "invalid input",
            "SOURCE": invoice_data[2],
            "INVOICE_AMOUNT": invoice_data[4],
            "VENDOR_NUM": ""
        }
        invalid_records.append(record)

    insert_invalid_records_into_dynamodb({group_id: invalid_records})

    return valid_lines_interface, valid_invoices_interface, invalid_lines_interface, invalid_invoices_interface


def boundary_inputs():
        
    url = oracle_url + const.ORACLE_REQUEST_PATH
    token = "Basic " + oracle_token
    headers = {"Authorization": token, "Content-Type": "application/soap+xml"}
    request = const.XML_FILE_NAME
    with open(request) as f:
        source_request_xml_data = f.read()

    source_oracle_response = requests.post(url, headers=headers, data=source_request_xml_data)
    source_oracle_response = source_oracle_response.content
    start_index = source_oracle_response.find(b"<ns2:reportBytes>") + len(b"<ns2:reportBytes>")
    end_index = source_oracle_response.find(b"</ns2:reportBytes>", start_index)
    source_oracle_response_data_encoded = source_oracle_response[start_index:end_index]
    source_oracle_response_data_decoded = b64decode(source_oracle_response_data_encoded).decode("utf-8")

    sources = []
    business_units = []
    lines = source_oracle_response_data_decoded.split('\n')

    for line in lines:
        if "<SOURCE>" in line:
            source = line.strip().replace("<SOURCE>", "").replace("</SOURCE>", "")
            sources.append(source)
        elif "<BUSINESS_UNIT>" in line:
            bu = line.strip().replace("<BUSINESS_UNIT>", "").replace("</BUSINESS_UNIT>", "")
            business_units.append(bu)

    return business_units, sources

    
def get_parameter(parameter_name):

    boto3_utility = Boto3Utility(parameter_name=parameter_name)
    parameter_response = boto3_utility.get_parameter()
    parameter_list = parameter_response['Parameter']['Value'].split(',')
    return parameter_list
    

# Generating the groupId
def generate_group_id():
    current_time = datetime.datetime.now()
    group_id = current_time.strftime("%Y%m%d%H%M%S%f")[:-3]
    return group_id

# Updating a DynamoDB item with information about a file processing event
def update_dynamodb(group_id, file_name):
    item = {
        'groupId': str(group_id),
        'referenceId': None,
        'fileName': str(file_name),
        'request': {
            'date': str(datetime.datetime.now()),
            'bucket': os.environ.get('bucket_name')
        },
        'status': {
            'key': 'in-progress',
            'message': 'Received payload'

        }
    }

    insert_dynamodb(item)

# Storing a dictionary item in DynamoDB
def insert_dynamodb(body): 
    dynamodb_helper = Boto3Utility(table_name=os.environ.get(FBDI_TABLE_NAME))
    dynamodb_helper.put_item(body)


# Updating a DynamoDB item to indicate a processing error
def update_error_dynamodb(group_id, file_name, msg):
    dynamodb_helper = Boto3Utility(table_name=os.environ.get(FBDI_TABLE_NAME))
    response = dynamodb_helper.get_item('groupId', group_id)
    if not response:
        item = {
            'groupId': str(group_id) if group_id else '',
            'fileName': str(file_name),
            'request': {
                'date': str(datetime.datetime.now()),
            },
            'status': {
                'key': 'failed',
                'message': 'failed due to error: ' + msg

            }
        }
    elif len(response) >0:
        item = response[0]
        item['status'] = {
            'key': 'failed',
            'message': 'failed due to error: ' + msg

        }
    dynamodb_helper.put_item(item)

def get_secret(secret_name,region_name):
    global ledger_id, organization_id, oracle_url, oracle_token
    boto3_utility = Boto3Utility(secret_name=secret_name, region=region_name)
    secret_json = boto3_utility.get_secret()
    oracle_url = str(secret_json["oracle_url"])
    oracle_token = str(secret_json["oracle_token"])
    ledger_id = str(secret_json["ledger_id"])
    organization_id = str(secret_json["organization_id"])