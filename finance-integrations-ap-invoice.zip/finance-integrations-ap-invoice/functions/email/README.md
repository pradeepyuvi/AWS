# EMAIL NOTIFICATION LAMBDA


This Lambda function will take the common workflow output data as input, modify that data, and send an email using it. If it fails at any stage, this Lambda function will handle the error and send a custom error message via email.