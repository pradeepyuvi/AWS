import boto3
import os
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication
import csv
import logging
import io
import sys

try:
    import const
except:
    from . import const


from boto3.dynamodb.conditions import Key


logger_level = os.environ.get('logger_level', 'INFO')
logger = logging.getLogger()
logger.setLevel(logger_level)


try:
    # This import will work in the Lambda environment
    from apinvoice.utility.Boto3Utility import Boto3Utility
except ImportError:
    # This import will work during local testing
    sys.path.append('../../')
    from layers.python.apinvoice.utility.Boto3Utility import Boto3Utility

ses_client=Boto3Utility(ses='ses')

# A lambda handler function
def handler(event, context):
    logger.info("function send mail starts")
    logger.info(event)
    error_msg = ''

    if 'errorDetails' in event:
        group_id = event['groupId']
    elif 'Output' in event:
        group_id = event['Output']['groupId']
    else:
        group_id = ''

    if 'errorDetails' in event or 'errorMessage' in event or 'Error' in event:
        error_msg = 'Failed during processing'
        send_mail(error_msg, None, None)
    else:
        try:
            dynamodb_helper = Boto3Utility(table_name=os.environ.get('fbdi_table'))
            response = dynamodb_helper.get_item('groupId', str(group_id))

            dynamodb_helper = Boto3Utility(table_name=os.environ.get('InvalidRecordsTable'))
            invalid_records_response = dynamodb_helper.get_item('groupId', str(group_id))
            print('invalid_records_response')
            print(invalid_records_response)
            
            report_summary = response[0]['response'].get('reportSummary', [])
            boundary_source = event["Output"]["request"]["data"]["Boundary_source"]
            if report_summary:
                filtered_data = [record for record in report_summary if record['STATUS'] == 'REJECTED']

                if filtered_data and invalid_records_response:
                    # Merge filtered_data and invalid_records_response
                    merged_data = filtered_data + invalid_records_response[0].get('invalidRecords', [])
                    
                    # Send an email with the merged data
                    send_mail(error_msg, merged_data, boundary_source)

                elif filtered_data:
                    # If only filtered_data exists,
                    # send an email with the filtered_data
                    send_mail(error_msg, filtered_data, boundary_source)

            
            return report_summary

        except Exception as error:
            logger.error('error: ' + str(error))
            raise error

    return None

# Send E-mail notification on error with the csv attachment
def send_mail(error_msg, csv_data, boundary_source):

    sender = os.environ.get('sender_email')
    receiver = os.environ.get('receiver_email')
    receiver_list = receiver.split(',') 
    charset = "utf-8"
    msg = MIMEMultipart('mixed')
    msg['Subject'] = const.SUBJECT
    msg['From'] = sender
    msg['To'] = receiver
    msg_body = MIMEMultipart('alternative')
    if boundary_source is not None :
        body_text = const.BODY_TEXT + ' for ' + str(boundary_source)
    else:
        body_text = const.BODY_TEXT
    body_text2 = const.BODY_TEXT2
    body_text3 = error_msg
    body_text4 = const.BODY_TEXT4
    body_text5 = const.BODY_TEXT5
    body_text = body_text + body_text2 + body_text3 + body_text4 + body_text5
    textpart = MIMEText(body_text.encode(charset), 'plain', charset)
    msg_body.attach(textpart)

    if csv_data:
        # Convert JSON to CSV and attach as a file
        csv_attachment = MIMEApplication(convert_json_to_csv(csv_data).encode(charset), _subtype="csv")
        csv_attachment.add_header('content-disposition', 'attachment', filename='ApInvoiceFailureRecords.csv')
        msg.attach(csv_attachment)

    msg.attach(msg_body)

    try:
        raw_msg={
                'Data': msg.as_string(),
            }
        response = ses_client.ses_send_raw_email(
            ses_sender=sender,
            ses_receiver_list=receiver_list,
            ses_raw_msg=raw_msg
        )
        logger.info("Message id : " + response['MessageId'])
        logger.info("Message sent successfully!")
    except Exception as error:
        logger.error('error: ' + str(error))
        raise error


# Convert JSON data to CSV format
def convert_json_to_csv(data):
    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=data[0].keys())
    writer.writeheader()
    for row in data:
        writer.writerow(row)
    return output.getvalue()