"""
A Boto3Utility Class
    - DynamoDB Helper  
    - Secret Manager Utility
"""

import boto3
import json
import logging
from boto3.dynamodb.conditions import Key, Attr
from aws_xray_sdk.core import xray_recorder

class Boto3Utility:

    # A Utility Class to perform Boto3 related Operations

    def __init__(self, bucket_name=None,table_name=None, secret_name=None, region=None,ses=None,statemachine_arn=None, parameter_name=None):
        """
        Initialize the Boto3 Utility.

        Args:
            table_name (str): The name of the DynamoDB table.
            secret_name (str): The name of the secret.
            region(str): The region of the resource.
        """
        if region != None:
            self.region = region
        if table_name != None:
            self.table_name = table_name
            self.dynamodb = boto3.resource('dynamodb')
            self.table = self.dynamodb.Table(self.table_name)
        if region != None and secret_name != None:
            self.secret_name = secret_name
            self.secret_client = boto3.client('secretsmanager', region_name=self.region)
        if bucket_name != None:
            self.bucket_name = bucket_name
            self.s3_resource = boto3.resource('s3')
            self.s3_client = boto3.client('s3')
        if  'ses'== ses :
            self.ses_client = boto3.client('ses')
        if statemachine_arn != None:
            self.statemachine_arn = statemachine_arn
            self.stepfunction_client = boto3.client('stepfunctions')  
        if parameter_name !=None:
            self.parameter_name = parameter_name
            self.ssm_client = boto3.client('ssm')

        self.logger = logging.getLogger(__name__)
        self.logger.setLevel(logging.INFO)  # Set your desired logging level here


    @xray_recorder.capture('dynamodb_put_item')
    def put_item(self, item):
        """
        Put an item into the DynamoDB table.

        Args:
            item (dict): The item to put into the table.
        """
        try:
            self.table.put_item(Item=item)
        except Exception as e:
            self.logger.error("Error putting item into DynamoDB: %s", e)
            raise
    
    @xray_recorder.capture('get_secret')
    def get_secret(self):
        """
        Get the value of the secret stored in Secrets Manager with the specific name and region

        """
        try:
            response = self.secret_client.get_secret_value(SecretId=self.secret_name)
            secret_json = json.loads(response['SecretString'])
            return secret_json
        except Exception as error:
            self.logger.error("Error fetching the secret from Secrets Manager: %s", error)
            raise
    
    @xray_recorder.capture('get_s3_resource_object')
    def get_s3_resource_object(self, file_name):
        """
        Get the object body from s3 bucket for the specific file name

        """
        try:
            response = self.s3_resource.Object(self.bucket_name, file_name)
            return response
        except Exception as error:
            self.logger.error("Error getting the object: %s", error)
            raise

    @xray_recorder.capture('read_s3_resource_object')
    def read_s3_resource_object(self, key):
        """
        Read the object from s3 bucket for the specific key name

        """
        try:
            response = self.s3_resource.Bucket(self.bucket_name).Object(key)
            return response
        except Exception as error:
            self.logger.error("Error getting the object: %s", error)
            raise

    @xray_recorder.capture('delete_s3_resource_object')
    def delete_s3_resource_object(self, key):
        """
        Read the object from s3 bucket for the specific key name

        """
        try:
            self.s3_resource.Object(self.bucket_name, key).delete()
        except Exception as error:
            self.logger.error("Error getting the object: %s", error)
            raise

    @xray_recorder.capture('get_s3_client_object')
    def get_s3_client_object(self, key):
        """
        Get the object body from s3 bucket for the specific file name

        """
        try:
            response = self.s3_client.get_object(Bucket=self.bucket_name, Key=key)
            return response
        except Exception as error:
            self.logger.error("Error getting the object: %s", error)
            raise

    @xray_recorder.capture('s3_client_upload_file')
    def s3_client_upload_file(self, file_name, key):
        """
        Put the file into s3 bucket for a specific file name

        """
        try:
            self.s3_client.upload_file(file_name, self.bucket_name, key)
        except Exception as error:
            self.logger.error("Error getting the object: %s", error)
            raise
    
    @xray_recorder.capture('s3_client_upload_file')
    def s3_client_put_object(self, key=None, body=None):
        """
        Put the object into s3 bucket

        """
        try:
            response = self.s3_client.put_object(Bucket=self.bucket_name, Key=key, Body=body)
            return response
        except Exception as error:
            self.logger.error("Error getting the object: %s", error)
            raise
    
    def query_global_index(self,index_name, key, key_value, fe,fe_value,exclusive_start_key=None):
        """
        Perform a query on the DynamoDB table.

        Args:
            key (str): The key attribute to query on.
            key_value: The value to match for the query.
            options: The key value pair of an extra parameter 

        Returns:
            list: A list of items matching the query.
        """
        try:
            if(None != exclusive_start_key) :
                response = self.table.query(
                        IndexName=index_name,
                        KeyConditionExpression=Key(key).eq(key_value),
                        FilterExpression=Attr(fe).eq(fe_value),
                        ExclusiveStartKey=exclusive_start_key
                        )

            elif(None == exclusive_start_key) :
                response = self.table.query(
                        IndexName=index_name,
                       KeyConditionExpression=Key(key).eq(key_value),
                        FilterExpression=Attr(fe).eq(fe_value)
                        )
            
            return response['Items']
        except Exception as e:
            self.logger.error("Error querying DynamoDB: %s", e)
            raise e

    def ses_send_raw_email(self,ses_sender,ses_receiver_list,ses_raw_msg):
        try:
            response=self.ses_client.send_raw_email(Source=ses_sender,
                Destinations=ses_receiver_list,
                RawMessage=ses_raw_msg
                )
            
            return response

        except Exception as error:
            self.logger.error("Error getting the object: %s", error)
            raise

    @xray_recorder.capture('invoke_step_function')
    def invoke_step_function(self, body):
        """
        Put the object into s3 bucket

        """
        try:
            response = self.stepfunction_client.start_execution(stateMachineArn=self.statemachine_arn, input=body)
            return response
        except Exception as error:
            self.logger.error("Error getting the object: %s", error)
            raise


    @xray_recorder.capture('get_parameter')
    def get_parameter(self):
        """
        Get the value of the secret stored in Secrets Manager with the specific name and region

        """
        try:
            response = self.ssm_client.get_parameter(Name=self.parameter_name)
            return response
        except Exception as error:
            self.logger.error("Error fetching the parameters from Parameters Store: %s", error)
            raise

    @xray_recorder.capture('get_item')
    def get_item(self, key, key_value):
        """
        Perform a query on the DynamoDB table.

        Args:
            key (str): The key attribute to query on.
            key_value: The value to match for the query.

        Returns:
            list: A list of items matching the query.
        """
        try:
            response = self.table.query(
                KeyConditionExpression=Key(key).eq(str(key_value))
            )
            return response['Items']
        except Exception as e:
            self.logger.error("Error querying DynamoDB: %s", e)
            return None